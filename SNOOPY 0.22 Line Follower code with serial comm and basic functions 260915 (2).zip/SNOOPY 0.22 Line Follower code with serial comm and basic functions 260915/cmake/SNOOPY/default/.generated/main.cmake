include("${CMAKE_CURRENT_LIST_DIR}/rule.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/file.cmake")

set(SNOOPY_default_library_list )

# Handle files with suffix (s|as|asm|AS|ASM|As|aS|Asm), for group default-XC8
if(SNOOPY_default_default_XC8_FILE_TYPE_assemble)
add_library(SNOOPY_default_default_XC8_assemble OBJECT ${SNOOPY_default_default_XC8_FILE_TYPE_assemble})
    SNOOPY_default_default_XC8_assemble_rule(SNOOPY_default_default_XC8_assemble)
    list(APPEND SNOOPY_default_library_list "$<TARGET_OBJECTS:SNOOPY_default_default_XC8_assemble>")

endif()

# Handle files with suffix S, for group default-XC8
if(SNOOPY_default_default_XC8_FILE_TYPE_assemblePreprocess)
add_library(SNOOPY_default_default_XC8_assemblePreprocess OBJECT ${SNOOPY_default_default_XC8_FILE_TYPE_assemblePreprocess})
    SNOOPY_default_default_XC8_assemblePreprocess_rule(SNOOPY_default_default_XC8_assemblePreprocess)
    list(APPEND SNOOPY_default_library_list "$<TARGET_OBJECTS:SNOOPY_default_default_XC8_assemblePreprocess>")

endif()

# Handle files with suffix [cC], for group default-XC8
if(SNOOPY_default_default_XC8_FILE_TYPE_compile)
add_library(SNOOPY_default_default_XC8_compile OBJECT ${SNOOPY_default_default_XC8_FILE_TYPE_compile})
    SNOOPY_default_default_XC8_compile_rule(SNOOPY_default_default_XC8_compile)
    list(APPEND SNOOPY_default_library_list "$<TARGET_OBJECTS:SNOOPY_default_default_XC8_compile>")

endif()

# Handle files with suffix elf, for group default-XC8
if(SNOOPY_default_default_XC8_FILE_TYPE_objcopy_lss)
add_library(SNOOPY_default_default_XC8_objcopy_lss OBJECT ${SNOOPY_default_default_XC8_FILE_TYPE_objcopy_lss})
    SNOOPY_default_default_XC8_objcopy_lss_rule(SNOOPY_default_default_XC8_objcopy_lss)
    list(APPEND SNOOPY_default_library_list "$<TARGET_OBJECTS:SNOOPY_default_default_XC8_objcopy_lss>")

endif()


# Main target for this project
add_executable(SNOOPY_default_image_xDhFYUpO ${SNOOPY_default_library_list})

set_target_properties(SNOOPY_default_image_xDhFYUpO PROPERTIES
    OUTPUT_NAME "default"
    SUFFIX ".elf"
    ADDITIONAL_CLEAN_FILES "${output_extensions}"
    RUNTIME_OUTPUT_DIRECTORY "${SNOOPY_default_output_dir}")
target_link_libraries(SNOOPY_default_image_xDhFYUpO PRIVATE ${SNOOPY_default_default_XC8_FILE_TYPE_link})
# Add the link options from the rule file.
SNOOPY_default_link_rule( SNOOPY_default_image_xDhFYUpO)


#Add objcopy steps
SNOOPY_default_objcopy_lss_rule(SNOOPY_default_image_xDhFYUpO)

