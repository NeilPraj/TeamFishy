# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.cmf]]
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.hex]]
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.hxl]]
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.mum]]
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.o]]
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.sdb]]
  [[C:\Users\Jesse\Downloads\SNOOPY 0.22 Line Follower code with serial comm and basic functions 260915\out\SNOOPY\default.sym]]
  )
endif()
